/*
*    main.js
*    Mastering Data Visualization with D3.js
*    Project 4 - FreedomCorp Dashboard
*/

d3.json("data/calls.json").then(data => {    
	console.log(data)
})