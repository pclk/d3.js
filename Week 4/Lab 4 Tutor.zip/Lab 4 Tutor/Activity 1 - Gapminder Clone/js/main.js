/*
*    main.js
*    Mastering Data Visualization with D3.js
*    Lab 4 Activity 1 - Gapminder Clone
*/

d3.json("data/data.json").then(function(data){
	console.log(data);
})