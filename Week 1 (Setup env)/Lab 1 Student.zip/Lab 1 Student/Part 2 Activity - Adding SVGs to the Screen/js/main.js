/*
*    main.js
*    Mastering Data Visualization with D3.js
*    Lab 1 - Part 2 Activity: Adding SVGs to the screen
*/

