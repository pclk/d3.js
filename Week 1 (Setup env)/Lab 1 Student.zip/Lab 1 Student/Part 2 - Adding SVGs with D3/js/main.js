/*
*    main.js
*    IT3382 - Advanced Data Visualisation
*    Lab 1 Part 2 - Adding SVGs with D3
*/
